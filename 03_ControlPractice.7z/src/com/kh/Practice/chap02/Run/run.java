package com.kh.Practice.chap02.Run;

import java.lang.reflect.Method;

import com.kh.Practice.chap02.loop.LoopPractice.LoopPractice;

public class run {
	
	public static void main (String[] args) {
		
		LoopPractice a = new LoopPractice();
				a.method12();
	}

}
