package com.kh.Practice.chap01.Run;

import com.kh.Practice.chap01.ControlPractice.ControlPractice;

public class run {
	
	public static void main(String[] args) {
		
		ControlPractice a = new ControlPractice();
		a.practice9();
		
		
		
	}

}
