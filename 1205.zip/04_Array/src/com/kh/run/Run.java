package com.kh.run;

import com.kh.array.A_Array;
import com.kh.array.B_ArrayCopy;

public class Run {

	public static void main (String[] args) {
		A_Array a = new A_Array();
				//a.method11();
		B_ArrayCopy b = new B_ArrayCopy();
		b.method5();
		
		
		
		
	}
}
