package com.kh.practice.func;

public class OperatorPractice {
	


}
