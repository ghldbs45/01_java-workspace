package com.kh.chap02.run;

import com.kh.chap02.loop.A_For;
import com.kh.chap02.loop.B_while;

public class LoopRun {

	public static void main(String[] args) {
		
		A_For a = new A_For();
				a.method10();
		
		B_while b = new B_while();
			//	b.method5();
	}
}
