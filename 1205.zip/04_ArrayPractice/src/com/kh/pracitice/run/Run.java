package com.kh.pracitice.run;

import com.kh.pracitice.array.Arraypractice;

public class Run {
	
	public static void main (String[] args) {
		
		Arraypractice a = new Arraypractice();
		a.practice10() ;
	}

}
