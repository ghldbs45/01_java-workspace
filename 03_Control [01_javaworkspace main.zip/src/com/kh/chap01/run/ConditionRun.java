package com.kh.chap01.run;

import com.kh.chap01.condition.A_if;
import com.kh.chap01.condition.B_Switch;

public class ConditionRun {
	
	public static void main(String[] args) {
		
		//A_if b = new A_if();
		
		B_Switch b = new B_Switch();
		b.method4();
				
	}

}
